package com.tns.onlineshopping.entities;

public class Admin extends user {
    public Admin(int userId, String username, String email) {
        super(userId, username, email);
    }
}
